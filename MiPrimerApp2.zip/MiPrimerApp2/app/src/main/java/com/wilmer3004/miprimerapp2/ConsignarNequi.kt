package com.wilmer3004.miprimerapp2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ConsignarNequi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consignar_nequi)
    }
}